Template.bulbsList.helpers({
    bulbs: function() {
        return Bulbs.find();
    }
});