Template.sparksList.helpers({
    sparks: function() {
        return Sparks.find();
    }
});